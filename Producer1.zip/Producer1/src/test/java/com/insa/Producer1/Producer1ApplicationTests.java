package com.insa.Producer1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Producer1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
