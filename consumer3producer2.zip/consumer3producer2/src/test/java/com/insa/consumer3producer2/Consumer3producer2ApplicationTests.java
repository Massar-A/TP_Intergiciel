package com.insa.consumer3producer2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Consumer3producer2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
