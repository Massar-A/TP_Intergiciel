package com.insa.consumer3producer2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Consumer3producer2Application {

	public static void main(String[] args) {
		SpringApplication.run(Consumer3producer2Application.class, args);
	}

}
