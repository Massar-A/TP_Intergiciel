package com.insa.consumer2producer3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Consumer2producer3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
